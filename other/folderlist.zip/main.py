import os;
import datetime;

import shutil;

#def copy(src, target):
#    s = open(src);
#    t = open(target, "w+");
#    for l in s:
#        t.write(l);
#    s.close();
#    t.close();

#def mdir():

lista = open("lista.txt");

files = [];

for l in lista:
    l = l.replace("\n", "")
    for f in os.scandir(l):
        print(f)
        files.append(f)

print(files)

out = "output\\";

date = datetime.date.today().strftime("%Y-%m-%d") + "\\";

if not os.path.exists(out + date):
    os.makedirs(out + date)

for f in files:
    if os.path.isfile(f):
        shutil.copy2(f.path, out + date + f.name)
    if os.path.isdir(f):
        shutil.copytree(f.path, out + date + f.name)


