import datetime;
import os;
date = datetime.datetime.now();

newline =  "\r\n";
filefolder = "notes\\";

if (not os.path.exists(filefolder)):
    os.mkdir(filefolder);

filename = date.strftime("%Y-%m-%d-%H-%M-%S") + ".txt";

open(filefolder + filename, "w");

os.system('notepad.exe "' + filefolder + filename + '"');

file = open(filefolder + filename, "r");
l = len(file.readlines());
file.close();


if (l == 0):
    file = open("-puste.txt", "a+");
    file.write(filefolder + filename + newline);
    file.close();
elif (l == 1):
    file = open("-krótkie.txt", "a+");
    file.write(filefolder + filename + newline);
    file.close();
elif (l < 10):
    file = open("-średnie.txt", "a+");
    file.write(filefolder + filename + newline);
    file.close();
elif (l > 10):
    file = open("-długie.txt", "a+");
    file.write(filefolder + filename + newline);
    file.close();
