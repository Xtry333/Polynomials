import os;
import datetime;

def createFolder(folder):
    if not os.path.exists(folder):
        os.makedirs(folder);

folder = "z6 dane";

today = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S");
#today = "override";

files = [];

data = dict();
weekly = dict();
weekly['sum'] = dict();

for f in os.scandir(folder):
    if f.is_file and f.name.endswith(".csv"):
        files.append(f);
        
for file in files:
    lN = 0;
    for l in open(file):
        if (not lN == 0):
            l = l.replace("\n", "");
            parts = l.split(",");
            if (not data.__contains__(parts[0])):
                data[parts[0]] = 0;
            d = parts[1].split(".");
            date = datetime.datetime(int(d[0]), int(d[1]), int(d[2]), int(d[3]), int(d[4]));
            print(parts[0], str(date), date.strftime("%W"));
            
            data[parts[0]] += int(parts[2]);
            
            if (not weekly.__contains__(parts[0])):
                weekly[parts[0]] = dict();
            if (not weekly['sum'].__contains__(date.strftime("%W"))):
                weekly['sum'][date.strftime("%W")] = 0;
            if (not weekly[parts[0]].__contains__(date.strftime("%W"))):
                weekly[parts[0]][date.strftime("%W")] = 0;
                
            weekly[parts[0]][date.strftime("%W")] += int(parts[2]);
            weekly['sum'][date.strftime("%W")] += int(parts[2]);
        lN += 1;

createFolder("output");
print(data);
out = open("output\\" + today + "-sum.csv", "w+");
out.write("Placówka, Suma\n");
for v in data:
    out.write(v + ", ")
    out.write(str(data[v]) + "\n");
out.close();

print(weekly);

for week in weekly['sum']:
    print("Week", week, "Avg:", weekly['sum'][week]/(len(weekly) - 1));

out = open("output\\" + today + "-avgWeekly.csv", "w+");
out.write("Tydzień, Średnia\n");
for week in weekly['sum']:
    out.write(str(week) + ", " + str(weekly['sum'][week]/(len(weekly) - 1)) + "\n");
out.close();

print("---");

out = open("output\\" + today + "-avgPerWeek.csv", "w+");
out.write("Placówka, Średnia na tydzień\n");
for place in weekly:
    if place != 'sum':
        i = 0;
        for week in weekly[place]:
            i += int(weekly[place][week]);
        out.write(str(place) + ", " + str(i/(len(weekly[place]))) + "\n");
        print("Place", place, "Avg:", i/(len(weekly[place])));
out.close();

#for item in ["sum", "avgWeekly", "avgAll"]:
#    out = open("output\\" + today + "-" + item + ".txt", "w+");
#    out.write("Placówka, Suma\n");
#    out.write("1,2\n");
#    out.close();

