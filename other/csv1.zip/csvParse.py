# Zadanie 3: Przetworzenie csv

print("\n-= CSV =-")

f = open("wyniki.csv")

line = f.readline()

el = line.replace("\n", "").split(";")

rowNum = 31

dct = dict()
dct["opis"] = [0]*rowNum

for i in range(rowNum):
    dct["opis"][i] = el[i+6]

dct["razem"] = [0]*rowNum

for line in f:
    parts = line.split(";")
    if (not dct.__contains__(parts[0])):
        dct[parts[0]] = [0]*rowNum
    for i in range(rowNum):
        dct[parts[0]][i] += int(parts[i+6])
        dct["razem"][i] += int(parts[i+6])

f.close()

print(dct)

f = open('wyniki.txt','w')
f.write(str(dct))
f.close()
